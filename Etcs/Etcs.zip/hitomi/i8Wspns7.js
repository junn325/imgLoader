var hitomi = { "h": { "exoclick": { "default": ["<script type=\"text/javascript\">var ad_idzone = \"2591161\", ad_width = \"728\", ad_height = \"90\";</script><script type=\"text/javascript\" src=\"https://ads.exosrv.com/ads.js\"></script><noscript><a href=\"https://main.exosrv.com/img-click.php?idzone=2591161\" target=\"_blank\"><img src=\"https://syndication.exosrv.com/ads-iframe-display.php?idzone=2591161&output=img&type=728x90\" width=\"728\" height=\"90\"></a></noscript>"] } }, "v": { "exoclick": { "default": ["<script type=\"text/javascript\">var ad_idzone = \"2591165\", ad_width = \"160\", ad_height = \"600\";</script><script type=\"text/javascript\" src=\"https://ads.exosrv.com/ads.js\"></script><noscript><a href=\"https://main.exosrv.com/img-click.php?idzone=2591165\" target=\"_blank\"><img src=\"https://syndication.exosrv.com/ads-iframe-display.php?idzone=2591165&output=img&type=160x600\" width=\"160\" height=\"600\"></a></noscript>"] } }, "mh": { "exoclick": { "default": ["<script type=\"text/javascript\">var ad_idzone = \"2591167\", ad_width = \"300\", ad_height = \"250\";</script><script type=\"text/javascript\" src=\"https://ads.exosrv.com/ads.js\"></script><noscript><a href=\"https://main.exosrv.com/img-click.php?idzone=2591167\" target=\"_blank\"><img src=\"https://syndication.exosrv.com/ads-iframe-display.php?idzone=2591167&output=img&type=300x250\" width=\"300\" height=\"250\"></a></noscript>"] } }, "sh": { "exoclick": { "default": ["<script type=\"text/javascript\">var ad_idzone = \"2591175\", ad_width = \"728\", ad_height = \"90\", v_pos = \"bottom\", h_pos = \"center\", eventMethod = window.addEventListener ? \"addEventListener\" : \"attachEvent\", eventer = window[eventMethod], messageEvent = (eventMethod == \"attachEvent\") ? \"onmessage\" : \"message\"; eventer(messageEvent, (function(ad_idzone){ return function(e) { if (e.data == \"show-iframe-\" + ad_idzone) document.getElementById(\"sticky-banner-\" + ad_idzone).style.display = \"\"; }; })(ad_idzone), false);</script><script type=\"text/javascript\" src=\"https://ads.exosrv.com/js.php?t=17&idzone=2591175\"></script>"] } } };

var pops = { "exoclick": { "pops": { "japanese": "document.write(\"<script type='text/javascript'>var ad_idzone = '1915792', ad_popup_fallback = true, ad_frequency_period = 5, ad_frequency_count = 1, ad_trigger_method = 2, ad_trigger_class = 'lillie';</script><script type='text/javascript' src='https://ads.exosrv.com/popunder1000.js'></script>     <script type='text/javascript'>document.addEventListener('DOMContentLoaded', function(event) { var myEl = {el: null}; var event = new CustomEvent('getvrsoxloader', {'detail': myEl}); window.document.dispatchEvent(event); var OxLoader = myEl.el;  OxLoader.getDetector().domain_base = 'exosrv.com';  OxLoader.addZone({'idzone':'1915792'});  OxLoader.serve({'script_url':'//ltn.hitomi.la/QUPJWWy/ycCzWo4f-3-1915792.js'}); });</script>\");", "asian": "document.write(\"<script type='text/javascript'>var ad_idzone = '1915796', ad_popup_fallback = true, ad_frequency_period = 5, ad_frequency_count = 1, ad_trigger_method = 2, ad_trigger_class = 'lillie';</script><script type='text/javascript' src='https://ads.exosrv.com/popunder1000.js'></script>     <script type='text/javascript'>document.addEventListener('DOMContentLoaded', function(event) { var myEl = {el: null}; var event = new CustomEvent('getvrsoxloader', {'detail': myEl}); window.document.dispatchEvent(event); var OxLoader = myEl.el;  OxLoader.getDetector().domain_base = 'exosrv.com';  OxLoader.addZone({'idzone':'1915796'});  OxLoader.serve({'script_url':'//ltn.hitomi.la/QUPJWWy/ycCzWo4f-3-1915796.js'}); });</script>\");", "cartoon": "document.write(\"<script type='text/javascript'>var ad_idzone = '1926866', ad_popup_fallback = true, ad_frequency_period = 5, ad_frequency_count = 1, ad_trigger_method = 2, ad_trigger_class = 'lillie';</script><script type='text/javascript' src='https://ads.exosrv.com/popunder1000.js'></script>     <script type='text/javascript'>document.addEventListener('DOMContentLoaded', function(event) { var myEl = {el: null}; var event = new CustomEvent('getvrsoxloader', {'detail': myEl}); window.document.dispatchEvent(event); var OxLoader = myEl.el;  OxLoader.getDetector().domain_base = 'exosrv.com';  OxLoader.addZone({'idzone':'1926866'});  OxLoader.serve({'script_url':'//ltn.hitomi.la/QUPJWWy/ycCzWo4f-3-1926866.js'}); });</script>\");" }, "timeout": 300, "weight": { "default": 100 } }, "popads": { "pops": { "default": "document.write(\"<script type='text/javascript' src='//ltn.hitomi.la/QUPJWWy/souXSSmW.js'></script>\");" }, "timeout": 0, "weight": { "default": 10 } }, "adsterra": { "weight": { "default": 1000 }, "timeout": 900, "pops": { "default": "document.write(\"<script type='text/javascript' src='//populateballoons.com/62/dd/f8/62ddf8004f8a9b0b786619a4cfd30ab0.js'></script>\");" } } };

var mobilepops = { "exoclick": { "pops": { "japanese": "document.write(\"<script type='text/javascript'>var ad_idzone = '2048577', ad_popup_fallback = true, ad_frequency_period = 5, ad_frequency_count = 1, ad_trigger_method = 2, ad_trigger_class = 'lillie';</script><script type='text/javascript' src='https://ads.exosrv.com/popunder1000.js'></script>     <script type='text/javascript'>document.addEventListener('DOMContentLoaded', function(event) { var myEl = {el: null}; var event = new CustomEvent('getvrsoxloader', {'detail': myEl}); window.document.dispatchEvent(event); var OxLoader = myEl.el;  OxLoader.getDetector().domain_base = 'exosrv.com';  OxLoader.addZone({'idzone':'2048577'});  OxLoader.serve({'script_url':'//ltn.hitomi.la/QUPJWWy/ycCzWo4f-11-2048577.js'}); });</script>\");", "asian": "document.write(\"<script type='text/javascript'>var ad_idzone = '2048569', ad_popup_fallback = true, ad_frequency_period = 5, ad_frequency_count = 1, ad_trigger_method = 2, ad_trigger_class = 'lillie';</script><script type='text/javascript' src='https://ads.exosrv.com/popunder1000.js'></script>     <script type='text/javascript'>document.addEventListener('DOMContentLoaded', function(event) { var myEl = {el: null}; var event = new CustomEvent('getvrsoxloader', {'detail': myEl}); window.document.dispatchEvent(event); var OxLoader = myEl.el;  OxLoader.getDetector().domain_base = 'exosrv.com';  OxLoader.addZone({'idzone':'2048569'});  OxLoader.serve({'script_url':'//ltn.hitomi.la/QUPJWWy/ycCzWo4f-11-2048569.js'}); });</script>\");", "cartoon": "document.write(\"<script type='text/javascript'>var ad_idzone = '2048571', ad_popup_fallback = true, ad_frequency_period = 5, ad_frequency_count = 1, ad_trigger_method = 2, ad_trigger_class = 'lillie';</script><script type='text/javascript' src='https://ads.exosrv.com/popunder1000.js'></script>     <script type='text/javascript'>document.addEventListener('DOMContentLoaded', function(event) { var myEl = {el: null}; var event = new CustomEvent('getvrsoxloader', {'detail': myEl}); window.document.dispatchEvent(event); var OxLoader = myEl.el;  OxLoader.getDetector().domain_base = 'exosrv.com';  OxLoader.addZone({'idzone':'2048571'});  OxLoader.serve({'script_url':'//ltn.hitomi.la/QUPJWWy/ycCzWo4f-11-2048571.js'}); });</script>\");" }, "timeout": 300, "weight": { "default": 100 } }, "popads": { "pops": { "default": "document.write(\"<script type='text/javascript' src='//ltn.hitomi.la/QUPJWWy/souXSSmW.js'></script>\");" }, "weight": { "default": 10 }, "timeout": 0 }, "adsterra": { "timeout": 900, "weight": { "default": 1000 }, "pops": { "default": "document.write(\"<script type='text/javascript' src='//populateballoons.com/62/dd/f8/62ddf8004f8a9b0b786619a4cfd30ab0.js'></script>\");" } } };

var hitomi_name = 'i8Wspns7';
var hitomi_horizontal_name = 'iCGyXi8o';
var hitomi_vertical_name = '5o7BMwB0';
var adsdir = 'QUPJWWy';
var backenddomain = 'ltn.hitomi.la';
var adsterra_domain = 'populateballoons.com';

/**
 * NeverBlock
 *
 * Version 3.7
 * Copyright (C) 2016 EXADS
 */
var ExoLoader;
(function () {
    var version = '3.7';

    var detection_started = false;
    var detection_complete = false;
    var adblock_detected = false;
    var detector_func_queue = [];

    var detector = {
        domain_base: "exoclick.com",
        detectCensorship: function (onComplete) {
            detector_func_queue.push(onComplete);
            detection_started = true;
            var block = false;
            var done = function () {
                if (!detection_complete) {
                    try {
                        var checkVal = (window.document.location.protocol !== "https:" && window.document.location.protocol !== "http:") ? "https:" : window.document.location.protocol;
                        if (typeof window.exoDocumentProtocol === "undefined"
                            || window.exoDocumentProtocol !== checkVal
                        ) {
                            block = true;
                        }
                    } catch (err) {
                        block = true;
                    }
                    adblock_detected = block;
                    detection_complete = true;
                } else {
                    block = adblock_detected;
                }
                do {
                    var currentFunction = detector_func_queue.shift();
                    if (typeof currentFunction === 'function') {
                        currentFunction(block);
                    }
                } while (typeof currentFunction !== "undefined");
                document.body.removeChild(testDomEl);
            };

            if (detection_complete) {
                done();
                return;
            }

            var testDomEl = document.createElement('iframe'),
                randomNum = Math.floor(Math.random() * (10000 - 123 + 1)) + 123,
                protocol = window.location.protocol,
                id = 'adsbox_ex_' + randomNum;

            testDomEl.setAttribute('height', "1px");
            testDomEl.setAttribute('width', "1px");
            testDomEl.setAttribute('id', id);
            testDomEl.setAttribute('class', 'adsBox pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads text-ad-links');
            testDomEl.setAttribute('style', "width: 1px !important; height: 1px !important; position: absolute !important; left: -10000px !important; top: -1000px !important; box-sizing: content-box !important; border-width: 0px !important;");

            try {
                if (window.ExoLoader === null) {
                    window.ExoLoader = { 'dummy': 1 };
                    if (window.ExoLoader !== { 'dummy': 1 }) {
                        block = true;
                    }
                }
            } catch (err) {
                block = true;
            }

            var testScript = document.createElement('script');
            testScript.src = protocol + "//ads." + detector.domain_base + "/ads.js";
            testScript.onerror = function () {
                block = true;
            };

            document.body.appendChild(testDomEl);
            document.head.appendChild(testScript);

            var domDetect = function () {
                try {
                    var someAd = document.getElementById(id);
                    if (someAd === null
                        || someAd.style.display === "none"
                        || someAd.style.display === "hidden"
                        || someAd.style.visibility === "hidden"
                        || someAd.offsetParent === null
                        || someAd.offsetHeight === 0
                        || someAd.offsetLeft === 0
                        || someAd.offsetTop === 0
                        || someAd.offsetWidth === 0
                        || someAd.clientHeight === 0
                        || someAd.clientWidth === 0
                    ) {
                        block = true;
                    }
                    if (window.getComputedStyle !== undefined) {
                        var style = window.getComputedStyle(someAd, null);
                        if (style && (style.getPropertyValue('display') === 'none' || style.getPropertyValue('visibility') === 'hidden')) {
                            block = true;
                        }
                    }
                } catch (err) {
                }
            };

            var maxReadyCheckAttempts = 45;
            var readyCheckInterval = setInterval(function () {
                if (document.readyState === "complete" || maxReadyCheckAttempts == "0") {
                    domDetect();
                    done();
                    clearInterval(readyCheckInterval);
                }
                maxReadyCheckAttempts--;
            }, 50);
        }
    };

    function urlDomain(url) {
        var a = document.createElement('a');
        a.href = url;
        return a.hostname;
    }

    var stylesheet = "{ %optional_styles% vertical-align:top; cursor: pointer; border: 0px solid #000000; display: inline-block; background-color: rgba(0, 0, 0, 0); margin: 0px 0px; padding: 0px 0px; }";
    var debug_messages = [];
    var error_messages = [];
    var request_stack = [];// array of request objects
    var responses = {};
    var callback_function_pushed_to_detector = false;
    var request_started = false;
    var current_request = 0;
    var waiting_request_queue = [];
    var before_detect_queue = [];

    var ZonesRequest = function () {
        this.zone_params = [];
        this.dom = [];
        this.pushZone = function (zoneParams) {
            this.zone_params.push(zoneParams);
        };
        this.pushDom = function (domObj) {
            this.dom.push(domObj);
        };
    };

    var addDebugMessage = function (message) {
        var date = new Date();
        debug_messages.push(date.toISOString() + ": " + message);
    };
    var addErrorMessage = function (message) {
        var date = new Date();
        error_messages.push(date.toISOString() + ": " + message);
        console.error(message);
    };

    var URLToArray = function (url) {
        var request = {};
        var pairs = url.substring(url.indexOf('?') + 1).split('&');
        for (var i = 0; i < pairs.length; i++) {
            if (!pairs[i])
                continue;
            var pair = pairs[i].split('=');
            request[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
        }
        return request;
    };

    var stringify = function (value) {
        var reassign_when_finished = false;
        if (typeof Array.prototype.toJSON !== 'undefined') {
            reassign_when_finished = true;
            var array_to_json = Array.prototype.toJSON;
            delete Array.prototype.toJSON;
        }
        var val = JSON.stringify(value);
        if (reassign_when_finished) {
            Array.prototype.toJSON = array_to_json;
        }
        return val;
    };

    var randStr = function (length, possibleChars) {
        var text = "";
        var possible = possibleChars || "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < length; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    };

    var createStyle = function (doc, dom_anchor, style_text) {
        var class_name = randStr(1, "abcdefghijklmnopqrstuvwxyz") + randStr(7);
        style_text = "." + class_name + " " + style_text;
        var style = doc.createElement('style');
        style.setAttribute('type', 'text/css');
        style.innerHTML = style_text;
        dom_anchor.parentNode.insertBefore(style, dom_anchor);
        return class_name;
    };
    var loader = {
        bl_domain: null,
        bl_cookie_domain: null,
        no_cookie: false,
        cookie_name: "yuo1",
        addZone: function (params) {

            if (typeof params !== 'object'
                || typeof params.idzone === 'undefined'
            ) {
                addErrorMessage("addZone() invalid params");
                return false;
            }
            var doc = params.doc || document;
            var scripts = doc.getElementsByTagName('script');
            var here = params.here || scripts[scripts.length - 1];

            if (!detection_complete) {
                addDebugMessage("addZone() added to detect queue");
                params.here = here;
                before_detect_queue.push({ "func": 'addZone', "parameters": params });

                if (!callback_function_pushed_to_detector) {
                    callback_function_pushed_to_detector = true;
                    detector.detectCensorship(function (block) {
                        if (block) {
                            window.exoNoExternalUI38djdkjDDJsio96 = true;
                            for (var i = 0; i < before_detect_queue.length; i++) {
                                loader[before_detect_queue[i]['func']](before_detect_queue[i]['parameters']);
                            }
                            before_detect_queue = [];
                        }
                    });
                }

                return false;
            } else {
                if (adblock_detected && !window.exoNoExternalUI38djdkjDDJsio96) {
                    window.exoNoExternalUI38djdkjDDJsio96 = true;
                }
                if (!adblock_detected) {
                    addDebugMessage("addZone() ad blocker not enabled");
                    return false;
                }
            }

            var request;
            if (typeof request_stack[current_request] === "object") {
                request = request_stack[current_request];
            } else {
                request = new ZonesRequest();
                request_stack[current_request] = request;
            }
            request.pushZone(params);

            var optional_styles = '';
            var displayNone = false;
            if (
                typeof params.width !== 'undefined'
                && typeof params.height !== 'undefined'
            ) {
                optional_styles += 'width: ' + params.width + 'px;';
                optional_styles += ' height: ' + params.height + 'px;';
            } else {
                displayNone = true;
            }

            var style_text = stylesheet.replace('%optional_styles%', optional_styles);
            var class_name = createStyle(doc, here, style_text);

            var placeholder = doc.createElement('div');
            if (displayNone) {
                placeholder.style.display = 'none';
            }
            placeholder.setAttribute('class', class_name);
            if (typeof params.container === "object" && typeof params.container.appendChild === "function") {
                params.container.appendChild(placeholder);
            } else {
                here.parentNode.insertBefore(placeholder, here);
            }
            request.pushDom({ 'placeholder': placeholder, 'doc_reference': doc });

            addDebugMessage("addZone() " + params.idzone + " added");
            return true;
        },
        serve: function (params) {
            /*
            params = {
                script_url: 'url/of/backend_loader.php',
                force: {false|true},
                no_cookie: {false|true}
            }

            Important note:
            If backend_loader.php & frontend_loader are hosted on different domains,
            don't forget to take care about CORS issues!
            In case the domains are not subdomains of a common domain it's impossible to pass data through cookie. no_cookie should be set to true.
            */

            if (!detection_complete) {
                addDebugMessage("serve() added to detect queue");
                params.force = true;
                before_detect_queue.push({ "func": 'serve', "parameters": params });
                return false;
            } else {
                if (adblock_detected && !window.exoNoExternalUI38djdkjDDJsio96) {
                    window.exoNoExternalUI38djdkjDDJsio96 = true;
                }
                if (!adblock_detected) {
                    addDebugMessage("serve() ad blocker not enabled");
                    return false;
                }
            }

            var request_id = current_request;
            var increment_current_request = true;
            if (typeof params.request_id !== "undefined" && params.request_id !== null) {
                request_id = params.request_id;
                increment_current_request = false;
            }
            var request = request_stack[request_id];

            if (typeof request === 'undefined'
                || request.zone_params.length < 1
            ) {
                addErrorMessage("serve() called but no zones added for request: " + request_id);
                return false;
            }

            if (increment_current_request) {
                current_request++;
            }

            if (request_started) {
                waiting_request_queue.push({ "request_id": request_id, "parameters": params });
                return;
            }

            addDebugMessage("serve() called for request " + request_id);
            request_started = true;
            var cookie_request_obj = {
                "objName": objName,
                "request_id": request_id,
                "zones": request.zone_params
            };

            loader.bl_domain = params.bl_domain || urlDomain(params.script_url); // Domain of backend_loader.php
            loader.bl_cookie_domain = params.bl_cookie_domain || loader.bl_domain;
            loader.no_cookie = params.no_cookie;

            var request_str = stringify(cookie_request_obj);

            if (!loader.no_cookie) {
                loader.setCookie(this.cookie_name, request_str, 5, loader.bl_cookie_domain);
            }
            delete request.zone_params.request_id;

            var loadDataScript = function () {
                var dataScript = document.createElement("script");
                dataScript.async = true;
                dataScript.setAttribute('type', 'text/javascript');
                var script_url = params.script_url;
                if (loader.no_cookie) {
                    script_url += (/\?/.test(params.script_url) ? '&' : '?') +
                        loader.cookie_name + '=' + request_str;
                }
                if (params.no_cache) {
                    script_url += (/\?/.test(params.script_url) ? '&' : '?') +
                        '_=' + randStr(3) + (new Date()).getTime(); // Avoid caching!
                }
                dataScript.setAttribute('src', script_url);
                dataScript.onload = function () {
                    addDebugMessage("serve() hosted script loaded");
                };
                var processNext = function () {
                    request_started = false;
                    if (waiting_request_queue.length > 0) {
                        var next_request_obj = waiting_request_queue.shift();
                        next_request_obj.parameters.request_id = next_request_obj.request_id;
                        loader.serve(next_request_obj.parameters);
                    }
                };
                dataScript.onload = processNext;
                dataScript.onerror = processNext;
                document.getElementsByTagName("body").item(0).appendChild(dataScript);
            };

            if (!params.force) {
                if (window.addEventListener) {
                    window.addEventListener("load", loadDataScript, false);
                } else if (window.attachEvent) {
                    window.attachEvent("onload", loadDataScript);
                } else {
                    window.onload = loadDataScript;
                }
            } else {
                loadDataScript();
            }
            return true;
        },
        getDebug: function () {
            for (var i = 0; i < debug_messages.length; i++) {
                console.log(debug_messages[i]);
            }
        },
        getVersion: function () {
            return version;
        },
        pushResponseData: function (response) {
            if (
                typeof response !== 'object'
                || typeof response.request_id !== 'number'
                || typeof request_stack[response.request_id] === 'undefined'
            ) {
                addErrorMessage("pushResponseData() invalid response");
            }
            responses[response.request_id] = response;
            addDebugMessage("pushResponseData() called for request " + response.request_id);
        },
        getAdData: function (request_id, ad_format) {
            var adData = {
                'zones': []
            };

            if (typeof request_stack[request_id] === 'undefined'
                || typeof responses[request_id] === 'undefined'
            ) {
                addErrorMessage("getAdData() data for request_id not found");
                return adData;
            }
            if (typeof responses[request_id].zones[ad_format] === 'undefined') {
                addErrorMessage("getAdData() data for ad_format " + ad_format + " not present in response");
                return adData;
            }

            for (var i = 0; i < responses[request_id].zones[ad_format].length; i++) {
                var adId = responses[request_id].zones[ad_format][i].id;
                var zone_params = request_stack[request_id].zone_params[adId];
                var idzone = zone_params.idzone;

                var zoneObj = {
                    "idzone": idzone,
                    "dom": request_stack[request_id].dom[adId],
                    "data": responses[request_id].zones[ad_format][i].data
                };
                if (typeof zone_params.sub !== 'undefined') {
                    zoneObj.sub = zone_params.sub;
                }
                if (typeof zone_params.sub2 !== 'undefined') {
                    zoneObj.sub2 = zone_params.sub2;
                }
                if (typeof zone_params.sub3 !== 'undefined') {
                    zoneObj.sub3 = zone_params.sub3;
                }
                if (typeof zone_params.cat !== 'undefined') {
                    zoneObj.cat = zone_params.cat;
                }
                adData.zones.push(zoneObj);
            }
            if (typeof responses[request_id].additional_images !== 'undefined'
                && typeof responses[request_id].additional_images[ad_format] !== 'undefined'
            ) {
                adData.additional_images = responses[request_id].additional_images[ad_format];
            }

            return adData;
        },
        openLink: function (event, dest, force_method) {
            if (typeof force_method !== 'undefined'
                && force_method !== 'get'
                && force_method !== 'post'
            ) {
                addErrorMessage("openLink() trying to force invalid method");
            }
            if (typeof (event) !== "undefined") {
                event.returnValue = false;
                if (event.preventDefault) {
                    event.preventDefault();
                }
                event.stopPropagation();
            }

            var url_parts;
            var parameters;
            var method;
            if (dest.indexOf("?") !== -1) {
                url_parts = dest.split('?', 2);
                parameters = URLToArray(url_parts[1]);
                method = (force_method) ? force_method : "post";
            } else {
                url_parts = [dest];
                parameters = [];
                method = (force_method) ? force_method : "get";
            }
            var f = document.createElement("form");
            f.setAttribute("action", url_parts[0]);
            f.setAttribute("method", method);
            f.setAttribute("target", "_blank");
            document.getElementsByTagName("body").item(0).appendChild(f);
            for (var i in parameters) {
                if (!parameters.hasOwnProperty(i)) {
                    continue;
                }
                var input = document.createElement("input");
                input.setAttribute("type", "hidden");
                input.setAttribute("name", i);
                input.setAttribute("value", parameters[i]);
                f.appendChild(input);
            }
            f.submit();
            document.getElementsByTagName("body").item(0).removeChild(f);
            return false;
        },
        formatImage: function (request_id, imageReference) {
            if (typeof request_stack[request_id] === 'undefined'
                || typeof responses[request_id] === 'undefined'
            ) {
                addErrorMessage("formatImage() data for request_id not found");
                return false;
            }
            var result = responses[request_id].banner_prefix + responses[request_id].images[imageReference];
            if (loader.bl_domain) {
                result = "//" + loader.bl_domain + result;
            }
            return result;
        },
        formatLink: function (request_id, link) {
            if (typeof request_stack[request_id] === 'undefined'
                || typeof responses[request_id] === 'undefined'
            ) {
                addErrorMessage("formatLink() data for request_id not found");
                return false;
            }
            var result = responses[request_id].link_prefix + link;
            if (loader.bl_domain) {
                result = "//" + loader.bl_domain + result;
            }
            return result;
        },
        setCookie: function (name, value, minutes_ttl, domain) {
            var exdate = new Date();
            exdate.setMinutes(exdate.getMinutes() + minutes_ttl);
            var c_value = encodeURI(value) + "; expires=" + exdate.toUTCString() + "; path=/";
            if (domain) {
                c_value += "; domain=" + domain;
            }
            document.cookie = name + "=" + c_value;
        },
        getCookie: function (name) {
            var i, x, y, ARRcookies = document.cookie.split(";");
            for (i = 0; i < ARRcookies.length; i++) {
                x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
                y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
                x = x.replace(/^\s+|\s+$/g, "");
                if (x === name) {
                    return decodeURI(y);
                }
            }
        },
        getRandomClassName: function () {
            return randStr(1, "abcdefghijklmnopqrstuvwxyz") + randStr(7);
        },
        getRandomizedReference: function (name, reference_map) {
            if (typeof name !== 'string' || name === '') {
                addErrorMessage("getRandomizedReference() invalid name, non-empty string expected");
                return false;
            }
            if (typeof reference_map !== 'object') {
                addErrorMessage("getRandomizedReference() invalid reference_map, object expected");
                return false;
            }
            if (typeof reference_map[name] === 'undefined') {
                reference_map[name] = loader.getRandomClassName();
            }
            return reference_map[name];
        },
        scrambleStyleString: function (style_str, reference_map, style_regexp) {
            if (typeof style_str !== 'string' || style_str === '') {
                addErrorMessage("scrambleStyleString() invalid style_str, non-empty string expected");
                return false;
            }
            if (typeof reference_map !== 'object') {
                addErrorMessage("getRandomizedReference() invalid reference_map, object expected");
                return false;
            }
            if (style_regexp instanceof RegExp) {
                var match;
                while (match = style_regexp.exec(style_str)) {
                    loader.getRandomizedReference(match[1], reference_map);
                }
            }
            for (var name in reference_map) {
                if (!reference_map.hasOwnProperty(name)) {
                    continue;
                }
                style_str = style_str.replace(new RegExp('([#\.]{1,1})' + name + '([ :\.{])', 'g'), '$1' + reference_map[name] + '$2');
            }
            return style_str;
        },
        getDetector: function () {
            return detector;
        },
        cleanupPartiallyBlockedAds: function () {
            detector.detectCensorship(
                function (block) {
                    if (block) {
                        var frames = document.getElementsByTagName("iframe");

                        for (var iNum = 0; iNum < frames.length; ++iNum) {
                            if (frames[iNum].src.indexOf("//" + detector.domain_base + "/") > 0) {
                                frames[iNum].style.display = "none";
                            }
                        }
                    }
                }
            );
        }
    };

    var objName;
    for (var tries = 0; tries < 3; tries++) {
        objName = randStr(1, "abcdefghijklmnopqrstuvwxyz") + randStr(Math.floor((Math.random() * 4) + 10));
        if (typeof window[objName] !== "undefined") {
            continue;
        }
        window[objName] = loader;
        break;
    }
    (function () {
        if (typeof window.CustomEvent === "function") return false;

        function CustomEvent(event, params) {
            params = params || { bubbles: false, cancelable: false, detail: undefined };
            var evt = document.createEvent('CustomEvent');
            evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
            return evt;
        }

        CustomEvent.prototype = window.Event.prototype;

        window.CustomEvent = CustomEvent;
    })();

    window.document.addEventListener('getvrsoxloader', function (e) {
        e.detail.el = loader;
    }, false);

})();








if (!Object.keys) {
    Object.keys = (function () {
        'use strict';
        var hasOwnProperty = Object.prototype.hasOwnProperty,
            hasDontEnumBug = !({ toString: null }).propertyIsEnumerable('toString'),
            dontEnums = [
                'toString',
                'toLocaleString',
                'valueOf',
                'hasOwnProperty',
                'isPrototypeOf',
                'propertyIsEnumerable',
                'constructor'
            ],
            dontEnumsLength = dontEnums.length;

        return function (obj) {
            if (typeof obj !== 'object' && (typeof obj !== 'function' || obj === null)) {
                throw new TypeError('Object.keys called on non-object');
            }

            var result = [], prop, i;

            for (prop in obj) {
                if (hasOwnProperty.call(obj, prop)) {
                    result.push(prop);
                }
            }

            if (hasDontEnumBug) {
                for (i = 0; i < dontEnumsLength; i++) {
                    if (hasOwnProperty.call(obj, dontEnums[i])) {
                        result.push(dontEnums[i]);
                    }
                }
            }
            return result;
        };
    }());
}

function user_lang() {
    var userLang = navigator.language || navigator.userLanguage;
    return userLang.toLowerCase();
}

function is_english() {
    var userLang = user_lang();
    return /^en/.test(userLang);
}

function is_asian() {
    var userLang = user_lang();
    return /^(?:ko|ja)/.test(userLang);
}

function on_mobile() { //http://stackoverflow.com/a/11381730/272601
    var check = false;
    (function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
}

function random_index(arr) {
    return Math.floor(Math.random() * arr.length);
}

function random_property(obj) {
    var result;
    var count = 0;
    for (var prop in obj)
        if (Math.random() < 1 / ++count)
            result = prop;
    return result;
}

function hitomi_inject(el, str) {
    $(el).html($(el).html() + str);
}

function da_etirw(hitomi_type) {
    if (on_mobile()) {
        hitomi_type = 'mobile' + hitomi_type;
    }

    var safety = 0;
    while (++safety <= 1000) {
        var format = random_property(hitomi);
        if (!format) break;

        var appropriateformats;
        if ('horizontal' === hitomi_type) {
            appropriateformats = ['h', 's', 'sw', 't'];
            appropriateformats = ['h'];  //changed 20150127 for a much more equal distribution of ads
        } else if ('vertical' === hitomi_type) {
            appropriateformats = ['v'];
        } else if ('mobilehorizontal' === hitomi_type) {
            appropriateformats = ['mh'];
        } else if ('stickyhorizontal' === hitomi_type) {
            appropriateformats = ['sh'];
        } else {
            break;
        }

        var found = false;
        for (var i = 0; i < appropriateformats.length; i++) {
            if (appropriateformats[i] === format) {
                found = true;
                break;
            }
        }
        if (!found) continue;

        var provider = random_property(hitomi[format]);
        if (!provider) continue;

        if ('tokyodollars' === provider || 'jlist' === provider) {
            if (!is_english()) {
                continue;
            }
        } else if ('nutaku' === provider) {
            if (is_asian()) {
                continue;
            }
        }

        var site = random_property(hitomi[format][provider]);
        if (!site) continue;

        var images_to_pick = 1;
        if ('s' === format) {
            images_to_pick = 6;
        } else if ('sw' === format) {
            images_to_pick = 3;
        } else if ('t' === format) {
            images_to_pick = 6;
        }

        var snippets = [];
        var picked = {};
        for (var number_picked = 0; number_picked < images_to_pick;) {
            var index = random_index(hitomi[format][provider][site]);

            if (Object.keys(picked).length === hitomi[format][provider][site].length) {
                picked = {};
            } else if (picked[index]) {
                continue;
            }
            picked[index] = 1;

            snippets.push(hitomi[format][provider][site][index]);
            number_picked++;
        }

        document.open();
        document.write(snippets.join(''));
        document.close();

        break;
    }
}

var rand = function (min, max) {
    return Math.random() * (max - min) + min;
};
var getRandomItem = function (list, weight) {
    var total_weight = weight.reduce(function (prev, cur, i, arr) {
        return prev + cur;
    });

    var random_num = rand(0, total_weight);
    var weight_sum = 0;

    for (var i = 0; i < list.length; i++) {
        weight_sum += weight[i];
        weight_sum = +weight_sum.toFixed(2);

        if (random_num <= weight_sum) {
            return list[i];
        }
    }
};

function get_json_cookie(cookie_name) {
    var cook = {};
    var from_cookie = Cookies.getJSON(cookie_name);
    if (from_cookie) {
        cook = from_cookie;
    }
    return cook;
}

function insert_hitomi_horizontal_div() {
    var div = document.getElementById('top-content');
    if (!div) return;

    var h = document.createElement('div');
    h.className = hitomi_horizontal_name;

    var s = document.createElement('script');
    s.src = '//' + backenddomain + '/' + hitomi_horizontal_name + '.js';
    h.appendChild(s);

    div.insertBefore(h, div.firstChild);
}

function insert_hitomi_vertical_div() {
    var div = document.getElementById('gallery-content');
    if (!div) return;

    var h = document.createElement('div');
    h.className = hitomi_vertical_name;

    var s = document.createElement('script');
    s.src = '//' + backenddomain + '/' + hitomi_vertical_name + '.js';
    h.appendChild(s);

    div.parentNode.insertBefore(h, div.nextSibling);
}

function pick_one_popup(override_mobile) {
    var cookie_name = 'hexoclick7';
    var cook = get_json_cookie(cookie_name);

    var popsource = pops;
    if (!override_mobile && on_mobile()) {
        popsource = mobilepops;
    }
    $.each(popsource, function (provider, v1) {
        $.each(popsource[provider]['pops'], function (pop, v2) {
            if (!cook[provider + '+' + pop]) return;

            var then = new Date(cook[provider + '+' + pop]);
            var now = new Date();
            if (now - then < popsource[provider]['timeout'] * 1000) { //it's not time yet
                delete popsource[provider]['pops'][pop];
                if (!Object.keys(popsource[provider]['pops']).length) {
                    delete popsource[provider];
                }
            } else {
                delete cook[provider + '+' + pop];
                Cookies.set(cookie_name, cook, { secure: true, expires: 1 }); //note that this is 1 day from now, not 1 day from when the cookie was initially set
            }
        });
    });
    var lang = user_lang().substring(0, 2);
    var langs = {};
    $.each(popsource, function (key, value) {
        $.each(value['weight'], function (weightlang, v) {
            langs[weightlang] = true;
        });
    });
    if (!langs[lang]) {
        lang = 'default';
    }

    var list = [];
    var weight = [];
    $.each(popsource, function (key, value) {
        list.push(key);
        weight.push(value['weight'][lang]);
    });
    if (!list.length) {
        if (!override_mobile) { //try again with non-mobile data structure (20160526)
            return pick_one_popup(true);
        }
        return;
    }
    var provider = getRandomItem(list, weight);
    var pop = random_property(popsource[provider]['pops']);

    cook[provider + '+' + pop] = new Date();
    Cookies.set(cookie_name, cook, { secure: true, expires: 1 }); //note that this is 1 day from now, not 1 day from when the cookie was initially set
    var buster = Math.round(new Date().getTime() / 1000);
    var hitomic_provider = provider;
    if (hitomic_provider === 'popads') {
        hitomic_provider = 'tomasz';
    }
    if (hitomic_provider === 'exoclick') {
        hitomic_provider = '2';
    }
    if (hitomic_provider === 'adsterra') {
        hitomic_provider = '3';
    }
    $.ajax({ url: '//hf2.hitomi.la/hitomic/' + hitomic_provider + '/' + pop + '/' + buster });

    document.open();
    var code = popsource[provider]['pops'][pop];
    eval(code); //can be document.write() or just raw js code - but raw js code did not work for popads for some reason - scope? (20160320)
    document.close();
}

pick_one_popup();
$(document).ready(function () {
    var script = document.createElement("script");
    script.setAttribute("type", "text/javascript");
    script.setAttribute("src", "//" + adsterra_domain + "/ef/c8/c8/efc8c87be3e95796a8038dff081d7a33.js");
    document.body.appendChild(script);
});
